import { patientSearch } from './services/getPatient.js';

export var serviceRoot = "https://fhir-open.sandboxcerner.com/dstu2/0b8a0111-e8e6-4c26-a91c-5069cbc6b1ca";
console.log('init loads')
console.log(patientSearch)