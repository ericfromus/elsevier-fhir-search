import { serviceRoot } from './init.js';

export var callPoint = serviceRoot;



